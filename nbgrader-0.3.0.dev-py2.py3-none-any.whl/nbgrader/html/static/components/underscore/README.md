Underscore
==========

Shim repository for [Underscore.js](http://underscorejs.org).

Package Managers
----------------

* [Bower](http://bower.io): `components-underscore`
* [Component](https://github.com/component/component): `components/underscore`
* [Composer](http://packagist.org/packages/components/underscore): `components/underscore`
