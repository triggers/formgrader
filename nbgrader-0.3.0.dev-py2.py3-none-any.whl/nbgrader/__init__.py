"""
A system for assigning and grading notebooks.
"""

from ._version import version_info, __version__
